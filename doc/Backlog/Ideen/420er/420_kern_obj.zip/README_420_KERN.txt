420er - Kernkomponenten (Originalgroesse, Einheit mm)
Grundlage: International 420 Class Rules, Fassung 31.03.2026. Rumpflaenge 4200 mm.

Enthaltene Einzelteile (freigegebene Komponenten):
  420_rumpf.obj       Rumpf nach Stefgran/Thingiverse 1593594 (CC BY-NC-SA), 30x auf 4200 mm,
                      gewelded (36168 Vertices / 72332 Faces), Bug = +X
  420_mast.obj        F.2.5: Laenge 6260, Querschnitt FA 72->54->40 / TR 62->48->36 (Grenzen 50-75/45-75)
  420_grossbaum.obj   F.3.5: Aussenpunkt 2400, Querschnitt konst. 75x55 (Grenzen 55-89/32-76)
  420_schwert.obj     E.3 + Diagramm 13/14: 995 lang, 420 breit, 18 dick, Fasen 45mm,
                      Pivotloch-Marker 920/80 mm (Grenzen 910-930 / 75-85)

Zusammenbau:
  420_zusammenbau.obj  Rumpf + Mast + Grossbaum + Schwert, montiert nach D.4.2:
    - Maststep-Vorderkante 2900 ab HDP (2890-2910) -> Mast bei d=2950, Fuss auf Kielson (Z=100)
    - Baum: Gooseneck bei d=2890, Hoehe Z=1350 (Lower Point 1160 ueber MDP), Aussenpunkt 2400
    - Schwert: Pivot d=1450 ab HDP (Kastenbereich 1400-1500), Wurzel auf Kastenkappe Z=560,
      Spitze ragt 435 mm unter Kiel (teilweise gefahren)

Koordinatensystem des Zusammenbaus: Ursprung im Rumpf-Koordinatensystem,
X nach vorn (Bug), Y quer, Z nach oben. HDP = Heckbezugspunkt bei X=0 des Rumpfs.
Einzelteile haben eigene lokale Systeme (siehe Kommentarzeile je Datei).
Blender: Import OBJ mit Skalierung 0.001 (mm -> m).

Ruder und Segel folgen in einer ueberarbeiteten Version.
