420er - Komplette Segel-Yacht (Originalgroesse, Einheit mm)
Grundlage: International 420 Class Rules 31.03.2026.
Rumpf: Stefgran/Thingiverse 1593594 (CC BY-NC-SA), 30x auf 4200 mm.

REVISION 6 - Grosssegel NEU nach Vorlagenbild (Segelplan):
  420_grosssegel.obj  Klassisches Dreieck, ebene Flaeche Y=0:
                      Tack    = Baumvorderende (Gooseneck), X=Luff, Z=1395
                      Head    = Mastspitze, Z=6290 (Vorliek 4895 mm vertikal)
                      Klau    = Baumende, X=Luff-2400 (Baumlaenge F.3.5)
                      Unterliek = gerade, laengs des Baums
                      Achterliek = sanft konvexe Kurve (Roach ~164 mm = 3.0% der
                      Sehne), aus dem Vorlagenbild abgenommen; kurvierte Laenge 10565 mm.
                      Flaeche 6.17 m2. Fan-Triangulierung ab Tack.
                      Hinweis: Mit Klau am Baumende betraegt die Achterliek-Sehne
                      5452 mm und liegt damit 52 mm ueber dem Regelmaximum 5400
                      (G.3.3). Reale 420er-Grosssegel setzen die Klau ca. 480 mm
                      vor das Baumende (Fuss 1920); die hier gewaehlte Voll-
                      Baum-Geometrie folgt der Vorgabe 'Mastspitze-Baumende-
                      Baumvorderende' fuer die Visualisierung.
  420_fock.obj        UNVERAENDERT (freigegeben): exaktes ebenes Dreieck
                      VL 3500 entlang Vorstag / Fuss 1750 / AL 3200 gerade.
  Vorstag als duennes Rohr im Zusammenbau enthalten.

Zusammenbau 420_zusammenbau.obj:
  Rumpf + Mast (d=2950, Fuss Kielson Z=100) + Grossbaum (Gooseneck d=2890, Z=1350)
  + Schwert (Pivot d=1450, Wurzel Z=560) + Grosssegel (Y=+10) + Fock (Y=-10) + Vorstag.
  Koordinatensystem: Rumpfsystem, X nach vorn (Bug), Z nach oben, HDP bei X=0.
  Einheit mm. Blender-Import: Skalierung 0.001.
