420 Isaf Sailing dinghy hull by Stefgran on Thingiverse: https://www.thingiverse.com/thing:1593594

Summary:
Here my 3D reconstruction of a 420 ISAF sail Dinghy, modeled from a 1959 "plan de forme".In the files you can find the Half hull and the entire hull, each scaled at the lenght of 140 mmYou can print the Half Hull using the middle section plane as base, and the Entire Hull using support grid.More informations about 420 international class here: http://www.420sailing.orgHave fun!