# 420er - 3D-Modelle (OBJ) nach Class Rules 2026

Generiert aus den International 420 Class Rules (effective 31 March 2026).
Einheiten: **Meter**. Szene: **+x = nach vorn (Bug), +y = Steuerbord, +z = nach oben**, Ursprung = Hull Datum Point (HDP, D.4.1 a).

## Dateien

| Datei | Objekt | Regelgrundlage | Bemerkung |
|---|---|---|---|
| 420_rumpf.obj | Rumpf + Deck | D.4.1: Laenge 4180-4220 mm, 10 Messsectionen mit min/max-Tiefen | Kiel-Tiefen = Mittel aus min/max; Breiten **schematisch** (Lines Plan Drawing 5 nicht oeffentlich) |
| 420_schwert.obj | Schwert | E.3, Diagramme 13/14: ~995 mm lang, 415-425 breit, 16-20 dick, Pivotloch 910-930/75-85 | Lokal: l ab Spitze O, c ab Anlaufkante, t Dicke; 45-mm-Fasen |
| 420_ruder.obj | Ruderblatt + Stock | E.4, C.8.3 (max 540 mm unter HDP) | Diagramm 15 nur als Bild -> Blattform **schematisch** |
| 420_mast.obj | Mast | F.2.5: 6260 mm, Querschnitt 50-75 vor/hinter, 45-75 quer | konisch vereinfacht |
| 420_grossbaum.obj | Grossbaum | F.3.5: Aussenpunkt 2400 mm, 55-89 vert / 32-76 quer | unverjuengt (F.3.3 b) |
| 420_grosssegel.obj | Grosssegel | G.3.3: Vorliek 4900, Fuss 1920, Breiten 2130/1630/995/480/115 | ebene Flaeche, Achterliek-Bogen ~5,6 m |
| 420_fock.obj | Fock | G.4.2: Vorliek 3500, Achterliek 3200, Fuss 1750 | Tack im Ursprung, Vorliek +z, Achterliek gerade |
| 420_szene.obj | Alles zusammen | - | Maststep x=2,90 (D.4.2 a(4)); Stemhead x=4,105 (D.4.2 a(1)); Schwert gesetzt (Pivot x=2,30, z=-0,10); Ruder am Transom |

## Annahmen / Vereinfachungen
1. Rumpfbreite/Decksform schematisch (massgeblich ist Drawing 5, lizenziert).
2. Ruderblattform schematisch (Diagramm 15 liegt nur als Grafik vor).
3. Segel eben, ohne Bauch, ohne Segeltaschen/Fenster/Zahlen.
4. Beschlaege und Spi-Ausruestung nicht modelliert.

Import in Blender: File > Import > Wavefront (.obj), Scale 1.0.
